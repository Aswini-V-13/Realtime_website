import 'dotenv/config';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import express from 'express';
import jwt from 'jsonwebtoken';
import { MongoClient } from 'mongodb';
import nodemailer from 'nodemailer';

const port = Number(process.env.PORT || 3001);
const mongoUri = process.env.MONGODB_URI;
const jwtSecret = process.env.JWT_SECRET;
const catalogApiUrl = 'https://dummyjson.com/products?limit=0';
const usdToInrRate = 84;

if (!mongoUri) {
  throw new Error('MONGODB_URI is required. Copy .env.example to .env and set your MongoDB connection string.');
}
if (!jwtSecret || jwtSecret.length < 32) {
  throw new Error('JWT_SECRET must be set to a random secret with at least 32 characters.');
}

const client = new MongoClient(mongoUri);
const app = express();
const smtpPort = Number(process.env.SMTP_PORT || 587);
const mailer = process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS
  ? nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: smtpPort,
    secure: smtpPort === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  })
  : null;
const asyncRoute = (handler) => (request, response, next) => {
  Promise.resolve(handler(request, response, next)).catch(next);
};
const validEmail = (email) => typeof email === 'string'
  && email.length <= 254
  && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
const objectBody = (body) => body && typeof body === 'object' && !Array.isArray(body) ? body : {};
const formatCategory = (category) => String(category || 'Other')
  .split('-')
  .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
  .join(' ');
const syncCatalog = async (collection) => {
  const response = await fetch(catalogApiUrl);
  if (!response.ok) {
    throw new Error(`Catalog API returned HTTP ${response.status}.`);
  }
  const payload = await response.json();
  if (!Array.isArray(payload.products) || payload.products.length === 0) {
    throw new Error('Catalog API did not return any products.');
  }

  const products = payload.products.map((item) => {
    const discount = Number(item.discountPercentage);
    const category = formatCategory(item.category);
    return {
      id: item.id,
      name: item.title,
      category,
      price: Math.round(Number(item.price) * usdToInrRate),
      oldPrice: Number.isFinite(discount) && discount > 0 && discount < 100
        ? Math.round((Number(item.price) / (1 - discount / 100)) * usdToInrRate)
        : null,
      rating: Number(item.rating) || 0,
      reviews: Array.isArray(item.reviews) ? item.reviews.length : 0,
      badge: Number.isFinite(discount) && discount > 0
        ? `${Math.round(discount)}% OFF`
        : `${category.toUpperCase()} PICK`,
      image: item.thumbnail || item.images?.[0] || '',
      description: item.description || `${item.title} from our ${category} collection.`,
    };
  });

  await collection.bulkWrite(products.map((product) => ({
    replaceOne: {
      filter: { id: product.id },
      replacement: product,
      upsert: true,
    },
  })));
  await collection.deleteMany({ id: { $nin: products.map((product) => product.id) } });
  return products.length;
};
const requireAuth = (request, response, next) => {
  const [scheme, token] = (request.get('authorization') || '').split(' ');
  if (scheme !== 'Bearer' || !token) {
    return response.status(401).json({ error: 'Sign in to access your cart.' });
  }
  try {
    const payload = jwt.verify(token, jwtSecret);
    if (typeof payload === 'string' || typeof payload.sub !== 'string') {
      return response.status(401).json({ error: 'Your session is invalid. Please sign in again.' });
    }
    request.userId = payload.sub;
    return next();
  } catch {
    return response.status(401).json({ error: 'Your session has expired. Please sign in again.' });
  }
};

app.use(express.json({ limit: '10kb' }));

app.get('/api/health', (request, response) => {
  response.json({ status: 'ok', database: 'connected' });
});

app.get('/api/categories', asyncRoute(async (request, response) => {
  const categories = await app.locals.products.distinct('category');
  response.json(categories.sort((left, right) => left.localeCompare(right)));
}));

app.get('/api/products', asyncRoute(async (request, response) => {
  const { category, q } = request.query;
  const filter = {};
  if (typeof category === 'string' && category !== 'All pieces' && category !== 'All finds') {
    filter.category = category;
  }
  if (typeof q === 'string' && q.trim()) {
    filter.$text = { $search: q.trim() };
  }
  const items = await app.locals.products.find(filter, { projection: { _id: 0 } }).sort({ id: 1 }).toArray();
  response.json(items);
}));

app.get('/api/cart', requireAuth, asyncRoute(async (request, response) => {
  const cart = await app.locals.carts.findOne({ userId: request.userId }, { projection: { _id: 0, userId: 0 } });
  response.json(cart || { items: [] });
}));

app.put('/api/cart', requireAuth, asyncRoute(async (request, response) => {
  const { items } = objectBody(request.body);
  if (!Array.isArray(items) || items.length > 50) {
    return response.status(400).json({ error: 'Cart items must be an array with no more than 50 products.' });
  }
  const seen = new Set();
  const validItems = items.every((item) => {
    const valid = item && typeof item === 'object'
      && Number.isSafeInteger(item.productId)
      && Number.isInteger(item.quantity)
      && item.quantity >= 1
      && item.quantity <= 99
      && !seen.has(item.productId);
    if (valid) seen.add(item.productId);
    return valid;
  });
  if (!validItems) {
    return response.status(400).json({ error: 'Each cart item needs a unique productId and a quantity from 1 to 99.' });
  }
  if (items.length) {
    const matchingProducts = await app.locals.products.countDocuments({ id: { $in: [...seen] } });
    if (matchingProducts !== seen.size) {
      return response.status(400).json({ error: 'One or more cart products do not exist.' });
    }
  }
  const cart = { userId: request.userId, items, updatedAt: new Date() };
  await app.locals.carts.updateOne(
    { userId: request.userId },
    { $set: cart },
    { upsert: true },
  );
  response.json({ items: cart.items });
}));

app.post('/api/auth/signup', asyncRoute(async (request, response) => {
  const { name, email, password } = objectBody(request.body);
  if (typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 100) {
    return response.status(400).json({ error: 'Name must be between 2 and 100 characters.' });
  }
  if (!validEmail(email)) return response.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
    return response.status(400).json({ error: 'Password must be between 8 and 128 characters.' });
  }
  const normalizedEmail = email.trim().toLowerCase();
  const passwordHash = await bcrypt.hash(password, 12);
  try {
    await app.locals.accounts.insertOne({
      name: name.trim(),
      email: normalizedEmail,
      passwordHash,
      createdAt: new Date(),
    });
    response.status(201).json({
      message: 'Your account has been created. Please sign in.',
      user: { name: name.trim(), email: normalizedEmail },
    });
  } catch (error) {
    if (error.code === 11000) return response.status(409).json({ error: 'An account with this email already exists.' });
    throw error;
  }
}));

app.post('/api/auth/login', asyncRoute(async (request, response) => {
  const { email, password } = objectBody(request.body);
  if (!validEmail(email) || typeof password !== 'string') {
    return response.status(400).json({ error: 'Enter a valid email address and password.' });
  }
  const normalizedEmail = email.trim().toLowerCase();
  const account = await app.locals.accounts.findOne({ email: normalizedEmail });
  if (!account || !await bcrypt.compare(password, account.passwordHash)) {
    return response.status(401).json({ error: 'Email or password is incorrect.' });
  }
  const token = jwt.sign({ sub: account._id.toString(), email: account.email }, jwtSecret, { expiresIn: '1d' });
  response.json({ token, user: { name: account.name, email: account.email } });
}));

app.post('/api/auth/forgot-password', asyncRoute(async (request, response) => {
  const { email } = objectBody(request.body);
  if (!validEmail(email)) return response.status(400).json({ error: 'Enter a valid email address.' });
  const normalizedEmail = email.trim().toLowerCase();
  const account = await app.locals.accounts.findOne({ email: normalizedEmail });
  if (!account) return response.status(404).json({ error: 'No account is registered with this email address.' });
  if (!mailer) {
    return response.status(503).json({ error: 'Password reset email is not configured. Add the SMTP settings to .env.' });
  }

  const otp = crypto.randomInt(100000, 1000000).toString();
  const otpHash = crypto.createHash('sha256').update(otp).digest('hex');
  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + 10 * 60 * 1000);
  await app.locals.passwordOtps.updateMany(
    { email: normalizedEmail, used: false },
    { $set: { used: true } },
  );
  const result = await app.locals.passwordOtps.insertOne({
    email: normalizedEmail,
    otpHash,
    used: false,
    expiresAt,
    createdAt,
  });
  try {
    await mailer.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: normalizedEmail,
      subject: 'Your Kartl password reset code',
      text: `Hello ${account.name},\n\nYour password reset code is ${otp}. It expires in 10 minutes.\n\nIf you did not request this, you can ignore this email.`,
    });
  } catch (mailError) {
    console.error('Could not send password reset email:', mailError);
    await app.locals.passwordOtps.updateOne({ _id: result.insertedId }, { $set: { used: true } });
    const error = new Error('Could not send the reset code. Check your SMTP settings and try again.');
    error.statusCode = 502;
    throw error;
  }
  response.json({ message: 'A password reset code has been sent to your registered email address.' });
}));

app.post('/api/auth/reset-password', asyncRoute(async (request, response) => {
  const { email, otp, newPassword } = objectBody(request.body);
  if (!validEmail(email)) return response.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof otp !== 'string' || !/^\d{6}$/.test(otp.trim())) {
    return response.status(400).json({ error: 'Enter the six-digit reset code sent to your email.' });
  }
  if (typeof newPassword !== 'string' || newPassword.length < 8 || newPassword.length > 128) {
    return response.status(400).json({ error: 'Password must be between 8 and 128 characters.' });
  }
  const normalizedEmail = email.trim().toLowerCase();
  const otpHash = crypto.createHash('sha256').update(otp.trim()).digest('hex');
  const otpRecord = await app.locals.passwordOtps.findOne({
    email: normalizedEmail,
    otpHash,
    used: false,
    expiresAt: { $gt: new Date() },
  });
  if (!otpRecord) return response.status(400).json({ error: 'This reset code is invalid, expired, or already used.' });
  const claim = await app.locals.passwordOtps.updateOne(
    { _id: otpRecord._id, used: false, expiresAt: { $gt: new Date() } },
    { $set: { used: true } },
  );
  if (claim.modifiedCount !== 1) {
    return response.status(400).json({ error: 'This reset code is invalid, expired, or already used.' });
  }
  const updatedAccount = await app.locals.accounts.updateOne(
    { email: normalizedEmail },
    { $set: { passwordHash: await bcrypt.hash(newPassword, 12) } },
  );
  if (updatedAccount.matchedCount !== 1) {
    return response.status(404).json({ error: 'No account is registered with this email address.' });
  }
  response.json({ message: 'Your password has been updated. You can now sign in.' });
}));

app.use((error, request, response, next) => {
  if (response.headersSent) return next(error);
  console.error(error);
  const status = Number.isInteger(error.statusCode) && error.statusCode >= 400 && error.statusCode < 600
    ? error.statusCode
    : 500;
  response.status(status).json({
    error: status === 500 ? 'A server error occurred. Please try again.' : error.message,
  });
});

const start = async () => {
  await client.connect();
  const database = client.db();
  app.locals.products = database.collection('products');
  app.locals.carts = database.collection('carts');
  app.locals.accounts = database.collection('accounts');
  app.locals.passwordOtps = database.collection('passwordOtps');
  try {
    await app.locals.carts.dropIndex('cartId_1');
  } catch (error) {
    if (![26, 27].includes(error.code)) throw error;
  }
  await Promise.all([
    app.locals.products.createIndex({ id: 1 }, { unique: true }),
    app.locals.products.createIndex({ name: 'text', category: 'text' }),
    app.locals.carts.createIndex({ userId: 1 }, { unique: true }),
    app.locals.accounts.createIndex({ email: 1 }, { unique: true }),
    app.locals.passwordOtps.createIndex({ email: 1, createdAt: -1 }),
  ]);
  const productCount = await syncCatalog(app.locals.products);
  console.log(`Synced ${productCount} products from DummyJSON into MongoDB.`);
  app.listen(port, () => console.log(`Kartl API is running at http://localhost:${port}`));
};

start().catch(async (error) => {
  console.error('Could not start the API or sync its DummyJSON catalog:', error.message);
  await client.close();
  process.exitCode = 1;
});
