import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const { PORT = '3001' } = loadEnv(mode, process.cwd(), '');
  return {
    server: {
      proxy: {
        '/api': `http://localhost:${PORT}`,
      },
    },
  };
});
