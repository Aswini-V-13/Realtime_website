# Kartl

A React storefront backed by an Express API and MongoDB. On startup, the backend fetches the catalog from DummyJSON (`https://dummyjson.com/products?limit=0`) and syncs it into MongoDB. The frontend loads products and categories from the backend API, uses it for account sign-up/sign-in and password resets, and saves signed-in carts to MongoDB. Guest carts, favourites, and order history are stored in the browser.

## Run locally

1. Install Node.js and start a local MongoDB server, or create a MongoDB Atlas database.
2. Copy `.env.example` to `.env`. Set `MONGODB_URI` and replace `JWT_SECRET` with a private random value at least 32 characters long.
3. Set `SMTP_USER` and `SMTP_PASS` to an email account and app password so password reset codes can be sent. For Gmail, use a Google app password.
4. Install dependencies with `npm install`.
5. In one terminal run `npm run server`.
6. In another terminal run `npm run dev`, then open the Vite URL it prints.

MongoDB stores accounts, password reset codes, the synced products, and signed-in carts in separate `accounts`, `passwordOtps`, `products`, and `carts` collections. Product prices are converted from the API's USD values to INR at a demo rate of ₹84 per US dollar. Reset codes expire after 10 minutes and can only be used once. Each signed-in user's cart is associated with their JWT user ID.

The browser calls the API through Vite's `/api` proxy; you can also call it directly at `http://localhost:3001`. Favorites and placed orders are currently browser-local; this API does not provide order or payment processing.

## Postman requests

Set `baseUrl` to `http://localhost:<PORT>` from `.env` (defaults to `http://localhost:3001`).

| Method | URL | Body |
| --- | --- | --- |
| GET | `{{baseUrl}}/api/health` | — |
| GET | `{{baseUrl}}/api/categories` | — |
| GET | `{{baseUrl}}/api/products?q=vase` | — |
| POST | `{{baseUrl}}/api/auth/signup` | `{"name":"Asha","email":"asha@example.com","password":"sample-pass-123"}` |
| POST | `{{baseUrl}}/api/auth/login` | `{"email":"asha@example.com","password":"sample-pass-123"}` |
| POST | `{{baseUrl}}/api/auth/forgot-password` | `{"email":"asha@example.com"}` |
| POST | `{{baseUrl}}/api/auth/reset-password` | `{"email":"asha@example.com","otp":"123456","newPassword":"another-pass-123"}` |
| GET | `{{baseUrl}}/api/cart` | — |
| PUT | `{{baseUrl}}/api/cart` | `{"items":[{"productId":1,"quantity":2}]}` |

Use `Content-Type: application/json` for requests with a body. Signup should return `201`; then use the same email and password with login, which should return a JWT. Duplicate signup returns `409`, and an incorrect login returns `401`. For both cart requests, set `Authorization: Bearer <token>` using the token from login. A cart request without a token returns `401`.

To test password reset, request a code for a registered email, use the code delivered to that inbox, and submit it with the email and new password. The reset code is never returned by the API.
