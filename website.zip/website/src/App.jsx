import React, { useEffect, useMemo, useRef, useState } from "react";

const PRODUCTS_PER_PAGE = 12;
const CART_STORAGE_KEY = "shopwise-cart-v2";
const ORDERS_STORAGE_KEY = "shopwise-orders-v2";
const FAVORITES_STORAGE_KEY = "shopwise-favorites-v1";
const CATEGORY_ART = {
  Books: {
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=520&q=85",
    subtitle: "A good story awaits",
    color: "cat-lilac",
  },
  Home: {
    image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=520&q=85",
    subtitle: "Make yourself at home",
    color: "cat-green",
  },
  Health: {
    image: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=520&q=85",
    subtitle: "A little you-time",
    color: "cat-peach",
  },
  Clothing: {
    image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=520&q=85",
    subtitle: "Made for your kind of day",
    color: "cat-pink",
  },
};
const money = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);

function normalizeCatalog(items) {
  if (!Array.isArray(items)) {
    throw new Error("The product response must be an array.");
  }

  const products = items.map((item) => {
    const category = String(item.category || "Other")
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
    const rawPrice = Number(item.price);
    const rawRating = Number(item.rating);
    if (!Number.isFinite(rawPrice) || rawPrice < 0) {
      throw new Error(`Product ${item.id} has an invalid price.`);
    }

    const image = typeof item.image === "string" && item.image.startsWith("http")
      ? item.image
      : item.image
        ? `https://images.unsplash.com/${item.image}?auto=format&fit=crop&w=800&q=85`
        : CATEGORY_ART[category]?.image || CATEGORY_ART.Home.image;
    return {
      id: item.id,
      name: item.name,
      category,
      price: rawPrice,
      originalPrice: item.oldPrice != null && Number.isFinite(Number(item.oldPrice))
        ? Number(item.oldPrice)
        : null,
      rating: Number.isFinite(rawRating) ? Math.min(5, Math.max(0, rawRating)) : 0,
      reviews: Number(item.reviews) || 0,
      image,
      fallbackImage: CATEGORY_ART[category]?.image || CATEGORY_ART.Home.image,
      badge: item.badge || `${category.toUpperCase()} PICK`,
      description: item.description || `${item.name} from our ${category} collection.`,
    };
  });

  return { categories: [...new Set(products.map((item) => item.category))], products };
}

async function apiRequest(path, { token, ...options } = {}) {
  const headers = new Headers(options.headers);
  if (options.body) headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch(`/api${path}`, { ...options, headers });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(result.error || `The request failed (${response.status}).`);
  }
  return result;
}

function cartPayload(items) {
  return items.map((item) => ({ productId: item.id, quantity: item.quantity }));
}

function mergeCarts(localCart, serverItems, products) {
  const productsById = new Map(products.map((product) => [product.id, product]));
  const quantities = new Map();
  for (const item of [...serverItems, ...cartPayload(localCart)]) {
    quantities.set(item.productId, Math.min(99, (quantities.get(item.productId) || 0) + item.quantity));
  }
  return [...quantities.entries()]
    .slice(0, 50)
    .map(([id, quantity]) => ({ ...productsById.get(id), quantity }))
    .filter((item) => item.id !== undefined);
}

function handleProductImageError(event, product) {
  if (!product.fallbackImage) return;
  event.currentTarget.onerror = null;
  event.currentTarget.src = product.fallbackImage;
}

function readStorage(key, fallback) {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch (error) {
    console.error(`Could not read ${key} from local storage.`, error);
    return fallback;
  }
}

function routeFromHash() {
  return window.location.hash.replace("#", "") || "home";
}

function App() {
  const [page, setPage] = useState(routeFromHash);
  const [products, setProducts] = useState([]);
  const [catalogCategories, setCatalogCategories] = useState([]);
  const [catalogStatus, setCatalogStatus] = useState("loading");
  const [displayCount, setDisplayCount] = useState(PRODUCTS_PER_PAGE);
  const [cart, setCart] = useState(() => readStorage(CART_STORAGE_KEY, []));
  const cartRef = useRef(cart);
  const [orders, setOrders] = useState(() => readStorage(ORDERS_STORAGE_KEY, []));
  const [favoriteIds, setFavoriteIds] = useState(() => readStorage(FAVORITES_STORAGE_KEY, []));
  const [user, setUser] = useState(() => readStorage("shopwise-user", null));
  const [token, setToken] = useState(() => readStorage("shopwise-token", ""));
  const [cartSyncReady, setCartSyncReady] = useState(() => !readStorage("shopwise-token", ""));
  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [category, setCategory] = useState("All finds");
  const [sort, setSort] = useState("featured");
  const [notice, setNotice] = useState("");
  const [orderConfirmation, setOrderConfirmation] = useState(null);
  const featuredShoe = products.find((product) => product.name.toLowerCase() === "red shoes");

  useEffect(() => {
    cartRef.current = cart;
  }, [cart]);

  useEffect(() => {
    const controller = new AbortController();
    Promise.all([
      apiRequest("/products", { signal: controller.signal }),
      apiRequest("/categories", { signal: controller.signal }),
    ])
      .then(([items, categories]) => {
        const normalizedCatalog = normalizeCatalog(items);
        setProducts(normalizedCatalog.products);
        setCatalogCategories(Array.isArray(categories) ? categories : normalizedCatalog.categories);
        setCatalogStatus("ready");
      })
      .catch((error) => {
        if (error.name === "AbortError") return;
        console.error("Could not load the product catalogue.", error);
        setCatalogStatus("error");
        setNotice(`We couldn't load the product catalogue: ${error.message}`);
      });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!token || catalogStatus !== "ready") {
      if (!token) setCartSyncReady(true);
      return undefined;
    }
    let active = true;
    setCartSyncReady(false);
    apiRequest("/cart", { token })
      .then(({ items }) => {
        if (!active) return;
        const mergedCart = mergeCarts(cartRef.current, items || [], products);
        setCart(mergedCart);
        return apiRequest("/cart", {
          token,
          method: "PUT",
          body: JSON.stringify({ items: cartPayload(mergedCart) }),
        });
      })
      .then(() => {
        if (active) setCartSyncReady(true);
      })
      .catch((error) => {
        if (!active) return;
        if (error.message.includes("session") || error.message.includes("Sign in")) {
          setToken("");
          setUser(null);
          setNotice("Your session has expired. Please sign in again.");
        } else {
          setNotice(`Could not load your saved cart: ${error.message}`);
        }
        setCartSyncReady(true);
      });
    return () => { active = false; };
  }, [token, catalogStatus, products]);

  useEffect(() => {
    const onHashChange = () => setPage(routeFromHash());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favoriteIds));
  }, [favoriteIds]);

  useEffect(() => {
    if (user) localStorage.setItem("shopwise-user", JSON.stringify(user));
    else localStorage.removeItem("shopwise-user");
  }, [user]);

  useEffect(() => {
    if (token) localStorage.setItem("shopwise-token", token);
    else localStorage.removeItem("shopwise-token");
  }, [token]);

  useEffect(() => {
    if (!token || !cartSyncReady) return;
    apiRequest("/cart", {
      token,
      method: "PUT",
      body: JSON.stringify({ items: cartPayload(cart) }),
    }).catch((error) => {
      console.error("Could not save the cart to the account.", error);
      setNotice(`Could not save your cart: ${error.message}`);
    });
  }, [cart, token, cartSyncReady]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(""), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const categories = ["All finds", ...catalogCategories];
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const favoriteProducts = products.filter((product) => favoriteIds.includes(product.id));
  const visibleProducts = useMemo(() => {
    const normalizedQuery = activeQuery.trim().toLowerCase();
    const matched = products.filter((product) => {
      const matchesCategory = category === "All finds" || product.category === category;
      const matchesQuery =
        !normalizedQuery ||
        `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(normalizedQuery);
      return matchesCategory && matchesQuery;
    });
    let sorted = matched;
    if (sort === "price-low") sorted = [...matched].sort((a, b) => a.price - b.price);
    else if (sort === "price-high") sorted = [...matched].sort((a, b) => b.price - a.price);
    else if (sort === "rating") sorted = [...matched].sort((a, b) => b.rating - a.rating);

    if (category === "All finds" && !normalizedQuery && featuredShoe && sorted.includes(featuredShoe)) {
      return [featuredShoe, ...sorted.filter((product) => product.id !== featuredShoe.id)];
    }
    return sorted;
  }, [activeQuery, category, products, sort, featuredShoe]);
  const displayedProducts = visibleProducts.slice(0, displayCount);

  function navigate(nextPage) {
    if (nextPage !== "orders") setOrderConfirmation(null);
    window.location.hash = nextPage;
    setPage(nextPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function search(event) {
    event.preventDefault();
    setActiveQuery(query);
    setCategory("All finds");
    setDisplayCount(PRODUCTS_PER_PAGE);
    setPage("home");
    window.location.hash = "home";
    document.getElementById("shop")?.scrollIntoView({ behavior: "smooth" });
  }

  function chooseCategory(nextCategory) {
    setCategory(nextCategory);
    setActiveQuery("");
    setQuery("");
    setDisplayCount(PRODUCTS_PER_PAGE);
    setPage("home");
    window.location.hash = "home";
    document.getElementById("shop")?.scrollIntoView({ behavior: "smooth" });
  }

  function addToCart(product) {
    if (!cart.some((item) => item.id === product.id) && cart.length >= 50) {
      setNotice("Your cart can contain up to 50 different products.");
      return;
    }
    setCart((current) => {
      const existing = current.find((item) => item.id === product.id);
      if (existing) {
        return current.map((item) =>
          item.id === product.id ? { ...item, quantity: Math.min(99, item.quantity + 1) } : item
        );
      }
      return [...current, { ...product, quantity: 1 }];
    });
    setNotice(`${product.name} added to your cart`);
  }

  function toggleFavorite(product) {
    const isFavorite = favoriteIds.includes(product.id);
    setFavoriteIds((current) =>
      current.includes(product.id)
        ? current.filter((id) => id !== product.id)
        : [...current, product.id]
    );
    setNotice(isFavorite ? `${product.name} removed from favourites` : `${product.name} added to favourites`);
  }

  function changeQuantity(productId, amount) {
    setCart((current) =>
      current
        .map((item) =>
          item.id === productId ? { ...item, quantity: Math.min(99, item.quantity + amount) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function completeOrder() {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const delivery = subtotal >= 1499 ? 0 : 79;
    const order = {
      id: `SW${Date.now().toString().slice(-8)}`,
      placedAt: new Date().toISOString(),
      items: cart,
      total: subtotal + delivery,
    };
    setOrders((current) => [order, ...current]);
    setCart([]);
    setOrderConfirmation(order);
    navigate("orders");
    setNotice(`Order placed successfully! Order #${order.id}`);
  }

  async function authenticate(event, mode) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get("email") || "").trim();
    try {
      if (mode === "forgot") {
        const result = await apiRequest("/auth/forgot-password", {
          method: "POST",
          body: JSON.stringify({ email }),
        });
        setNotice(result.message);
        navigate("reset");
        return;
      }
      if (mode === "reset") {
        const result = await apiRequest("/auth/reset-password", {
          method: "POST",
          body: JSON.stringify({
            email,
            otp: String(data.get("otp") || ""),
            newPassword: String(data.get("password") || ""),
          }),
        });
        setNotice(result.message);
        navigate("login");
        return;
      }
      const password = String(data.get("password") || "");
      if (mode === "signup") {
        await apiRequest("/auth/signup", {
          method: "POST",
          body: JSON.stringify({ name: String(data.get("name") || ""), email, password }),
        });
      }
      const result = await apiRequest("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setUser(result.user);
      setCartSyncReady(false);
      setToken(result.token);
      setNotice(mode === "signup" ? "Welcome to Kartl!" : `Welcome back, ${result.user.name}!`);
      navigate("home");
    } catch (error) {
      setNotice(error.message);
    }
  }

  function signOut() {
    setUser(null);
    setToken("");
    setCartSyncReady(true);
    setNotice("You’ve been signed out.");
    navigate("home");
  }

  return (
    <div className="app-shell">
      <div className="announcement">
        <span className="announcement-spark">✦</span> A little treat: free delivery on orders over ₹1,499
        <span className="announcement-note">Made for your everyday happy.</span>
      </div>
      <header className="site-header">
        <button className="brand" onClick={() => navigate("home")} aria-label="Kartl home">
          <span className="brand-mark">K<span>✳</span></span>
          <span>Kartl<span className="brand-period">.</span></span>
        </button>
        <form className="search-bar" onSubmit={search}>
          <span className="search-icon" aria-hidden="true">⌕</span>
          <input
            aria-label="Search products"
            placeholder="Search for something lovely..."
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
          {query && <button className="clear-search" type="button" onClick={() => setQuery("")} aria-label="Clear search">×</button>}
          <button className="search-submit" type="submit">Search</button>
        </form>
        <div className="header-actions">
          <button className="header-link account-link" onClick={() => navigate(user ? "account" : "login")}>
            <span className="action-icon">♙</span>
            <span><small>Hello, {user ? user.name.split(" ")[0] : "there"}</small><strong>My account</strong></span>
          </button>
          <button className="header-link cart-link" onClick={() => navigate("cart")} aria-label={`Cart, ${cartCount} items`}>
            <span className="cart-icon">🛒{cartCount > 0 && <i>{cartCount}</i>}</span>
            <span><small>Your</small><strong>Cart</strong></span>
          </button>
          <button className="header-link favorite-link" onClick={() => navigate("favorites")} aria-label={`Favourites, ${favoriteIds.length} items`}>
            <span className="favorite-icon">♥{favoriteIds.length > 0 && <i>{favoriteIds.length}</i>}</span>
            <span><small>Your</small><strong>Favourites</strong></span>
          </button>
        </div>
      </header>
      <nav className="category-nav" aria-label="Shop categories">
        <div className="nav-inner">
          <button className="nav-home" onClick={() => chooseCategory("All finds")}>⌂ <span>Shop all</span></button>
          {categories.slice(1).map((item) => (
            <button key={item} className={category === item ? "nav-category active" : "nav-category"} onClick={() => chooseCategory(item)}>
              {item}
            </button>
          ))}
          <button className="nav-deal" onClick={() => chooseCategory("All finds")}>A little more joy <span>→</span></button>
        </div>
      </nav>

      <main>
        {page === "home" && (
          <>
            <section className="hero">
              <div className="hero-copy">
                <span className="eyebrow"><span className="eyebrow-dot" /> GOOD THINGS, GOOD MOOD</span>
                <h1>Find your<br />everyday <em>happy.</em></h1>
                <p>Thoughtful little finds for the big and small moments that make your day.</p>
                <button className="primary-button hero-button" onClick={() => document.getElementById("shop")?.scrollIntoView({ behavior: "smooth" })}>
                  Find your favourite <span>↗</span>
                </button>
                <div className="hero-proof"><span className="proof-stars">★★★★★</span><strong>4.9/5</strong><span>from 2,000+ happy finds</span></div>
              </div>
              <div className="hero-art" aria-label="A curated collection of colourful everyday products">
                <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
                <div className="hero-photo photo-large"><img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=850&q=90" alt="Red shoes" /></div>
                <div className="hero-photo photo-small"><img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=500&q=85" alt="Wireless headphones" /></div>
                <div className="float-note note-top"><span>✦</span> little things<br />big joy</div>
                <div className="float-note note-bottom"><span>♡</span> picked with<br />you in mind</div>
                <span className="hero-doodle doodle-one">✳</span><span className="hero-doodle doodle-two">✦</span>
              </div>
              <div className="hero-counter"><strong>01</strong><span>—</span> 03</div>
            </section>

            <section className="perks-strip" aria-label="Kartl promises">
              <div className="perk"><span className="perk-icon">✿</span><div><strong>Good things, fair prices</strong><small>Little treats that feel just right</small></div></div>
              <div className="perk"><span className="perk-icon">↗</span><div><strong>At your door, pronto</strong><small>Free delivery over ₹1,499</small></div></div>
              <div className="perk"><span className="perk-icon">♡</span><div><strong>Happy or it's not right</strong><small>Easy 7-day returns</small></div></div>
              <div className="perk"><span className="perk-icon">♧</span><div><strong>Little joys, big impact</strong><small>Thoughtful picks every time</small></div></div>
            </section>

            <section className="category-section">
              <div className="section-heading">
                <div><span className="eyebrow">A LITTLE SOMETHING FOR EVERYONE</span><h2>What are you in the mood for?</h2></div>
                <button className="text-link" onClick={() => chooseCategory("All finds")}>See it all <span>↗</span></button>
              </div>
              <div className="category-cards">
                {catalogCategories.map((name) => {
                  const fallbackArt = CATEGORY_ART[name] || CATEGORY_ART.Home;
                  const categoryImage = products.find((product) => product.category === name)?.image || fallbackArt.image;
                  return (
                    <button className={`category-card ${fallbackArt.color}`} key={name} onClick={() => chooseCategory(name)}>
                      <span className="category-card-copy"><strong>{name}</strong><small>{fallbackArt.subtitle || "A little something for you"}</small><span className="category-arrow">↗</span></span>
                      <img src={categoryImage} alt="" onError={(event) => handleProductImageError(event, { fallbackImage: fallbackArt.image })} />
                    </button>
                  );
                })}
              </div>
            </section>

            <section className="shop-section" id="shop">
              <div className="section-heading shop-heading">
                <div>
                  <span className="eyebrow">{activeQuery ? "YOUR SEARCH, OUR FINDS" : "THE INTERNET'S LITTLE HAPPY PLACE"}</span>
                  <h2>{activeQuery ? `Results for “${activeQuery}”` : category === "All finds" ? "Good finds, just for you." : `${category}, picked for you.`}</h2>
                </div>
                <label className="sort-control">Sort by
                  <select value={sort} onChange={(event) => { setSort(event.target.value); setDisplayCount(PRODUCTS_PER_PAGE); }} aria-label="Sort products">
                    <option value="featured">Featured</option><option value="price-low">Price: low to high</option>
                    <option value="price-high">Price: high to low</option><option value="rating">Top rated</option>
                  </select>
                </label>
              </div>
              <p className="catalog-note">A little collection of finds, picked just for you.</p>
              {catalogStatus === "loading" ? (
                <div className="catalog-message" role="status">Finding your happy things…</div>
              ) : catalogStatus === "error" ? (
                <div className="catalog-message" role="alert">We couldn't load products. Check your connection and refresh to try again.</div>
              ) : visibleProducts.length ? (
                <div className="product-grid">
                  {displayedProducts.map((product) => <ProductCard key={product.id} product={product} onAdd={addToCart} onToggleFavorite={toggleFavorite} isFavorite={favoriteIds.includes(product.id)} />)}
                </div>
              ) : (
                <div className="empty-search"><span>⌕</span><h3>No little finds just yet</h3><p>Try a different search or browse all of our happy things.</p><button className="primary-button" onClick={() => { setActiveQuery(""); setQuery(""); chooseCategory("All finds"); }}>See all finds</button></div>
              )}
              {displayCount < visibleProducts.length && (
                <div className="load-more-wrap">
                  <p>Showing {displayedProducts.length} of {visibleProducts.length} finds</p>
                  <button className="outline-button" onClick={() => setDisplayCount((count) => count + PRODUCTS_PER_PAGE)}>Load more finds <span>↓</span></button>
                </div>
              )}
            </section>

            <section className="newsletter">
              <div className="newsletter-star">✳</div>
              <div><span className="eyebrow">A LITTLE NOTE FROM US</span><h2>Good things in your inbox.</h2><p>Fresh finds, happy deals, and a little sunshine. No spam, promise.</p></div>
              <form className="newsletter-form" onSubmit={(event) => { event.preventDefault(); setNotice("You’re on the list! Watch your inbox for happy things."); event.currentTarget.reset(); }}>
                <input type="email" placeholder="Your email address" aria-label="Your email address" required />
                <button type="submit">Count me in <span>→</span></button>
              </form>
            </section>
          </>
        )}

        {page === "cart" && (
          <section className="page-section">
            <PageTitle eyebrow="YOUR LITTLE HAPPY PLACE" title="Your cart." onBack={() => navigate("home")} />
            {cart.length ? <CartPage cart={cart} onChange={changeQuantity} onCheckout={() => navigate(user ? "checkout" : "login")} onShop={() => navigate("home")} /> : <EmptyState icon="🛒" title="Your cart is empty." text="Fill it with things that make you smile." button="Find something lovely" onClick={() => navigate("home")} />}
          </section>
        )}

        {page === "favorites" && (
          <section className="page-section">
            <PageTitle eyebrow="SAVED FOR A HAPPY DAY" title="Your favourites." onBack={() => navigate("home")} />
            {catalogStatus === "loading" ? (
              <div className="catalog-message" role="status">Loading your favourites…</div>
            ) : favoriteProducts.length ? (
              <div className="product-grid">
                {favoriteProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAdd={addToCart}
                    onToggleFavorite={toggleFavorite}
                    isFavorite
                  />
                ))}
              </div>
            ) : (
              <EmptyState icon="♡" title="No favourites saved yet." text="Tap the heart on anything you love and it will be saved here." button="Browse products" onClick={() => navigate("home")} />
            )}
          </section>
        )}

        {page === "checkout" && (
          <section className="page-section">
            <PageTitle eyebrow="ALMOST YOURS" title="Let's get it to you." onBack={() => navigate("cart")} />
            {cart.length ? <CheckoutPage cart={cart} user={user} onPlace={completeOrder} /> : <EmptyState icon="♡" title="Nothing to check out just yet." text="Your next favourite thing is waiting to be found." button="Browse the shop" onClick={() => navigate("home")} />}
          </section>
        )}

        {page === "orders" && (
          <section className="page-section">
            <PageTitle eyebrow="THE HAPPY STUFF" title="Your orders." onBack={() => navigate("home")} />
            {orderConfirmation && (
              <div className="order-confirmation" role="status">
                <span className="confirmation-check">✓</span>
                <div><strong>Order placed successfully!</strong><p>Order #{orderConfirmation.id} · Total {money(orderConfirmation.total)}</p></div>
              </div>
            )}
            {orders.length ? <div className="orders-list">{orders.map((order) => <OrderCard key={order.id} order={order} />)}</div> : <EmptyState icon="✿" title="Your happy mail is yet to begin." text="Orders you place will show up right here." button="Start exploring" onClick={() => navigate("home")} />}
          </section>
        )}

        {["login", "signup", "forgot", "reset"].includes(page) && (
          <AuthPage page={page} onSubmit={authenticate} onNavigate={navigate} />
        )}

        {page === "account" && (
          <section className="page-section account-page">
            <PageTitle eyebrow="YOUR KARTL SPACE" title={`Hello, ${user?.name || "there"}!`} onBack={() => navigate("home")} />
            <div className="account-card"><div className="account-avatar">{user?.name?.charAt(0).toUpperCase() || "S"}</div><div><h3>{user?.name}</h3><p>{user?.email}</p></div><div className="account-actions"><button className="outline-button" onClick={() => navigate("orders")}>My orders <span>↗</span></button><button className="subtle-button" onClick={signOut}>Sign out</button></div></div>
          </section>
        )}
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <div className="footer-brand"><button className="brand" onClick={() => navigate("home")}><span className="brand-mark">K<span>✳</span></span><span>Kartl<span className="brand-period">.</span></span></button><p>Little finds, big joy.<br />A happy little corner of the internet.</p><div className="social-dots"><span>ig</span><span>in</span><span>f</span></div></div>
          <div className="footer-column"><strong>Find your thing</strong><button onClick={() => chooseCategory("All finds")}>Shop all</button>{categories.slice(1, 5).map((item) => <button key={item} onClick={() => chooseCategory(item)}>{item}</button>)}</div>
          <div className="footer-column"><strong>Here to help</strong><button onClick={() => navigate("account")}>Your account</button><button onClick={() => navigate("orders")}>Track an order</button><button onClick={() => navigate("cart")}>Your cart</button><button onClick={() => navigate("favorites")}>Your favourites</button><span>hello@kartl.example</span></div>
          <div className="footer-note"><span>✳</span><strong>Life's too short<br />for boring finds.</strong><small>Happy shopping, friend.</small></div>
        </div>
        <div className="footer-bottom"><span>© 2025 Kartl. Made with a little extra love.</span><span>Made for everyday happy <b>♡</b></span><span>INR · India</span></div>
      </footer>
      {notice && <div className="toast" role="status"><span>✦</span>{notice}<button onClick={() => setNotice("")} aria-label="Dismiss notification">×</button></div>}
    </div>
  );
}

function ProductCard({ product, onAdd, onToggleFavorite, isFavorite }) {
  return (
    <article className="product-card" data-product-id={product.id}>
      <div className="product-image" role="group" aria-label={product.name}>
        <span className="product-badge">{product.badge}</span>
        <button className={isFavorite ? "wishlist-button wishlisted" : "wishlist-button"} aria-label={isFavorite ? `Remove ${product.name} from favourites` : `Add ${product.name} to favourites`} aria-pressed={isFavorite} onClick={(event) => { event.stopPropagation(); onToggleFavorite(product); }}>{isFavorite ? "♥" : "♡"}</button>
        <img src={product.image || product.fallbackImage} alt={product.name} loading="lazy" onError={(event) => handleProductImageError(event, product)} />
      </div>
      <div className="product-info">
        <span className="product-category">{product.category}</span>
        <h3>{product.name}</h3>
        <div className="product-rating"><span>{"★".repeat(Math.round(product.rating))}{"☆".repeat(5 - Math.round(product.rating))}</span><small>{product.rating}/5</small></div>
        <div className="product-bottom"><div><strong>{money(product.price)}</strong>{product.originalPrice && <del>{money(product.originalPrice)}</del>}</div><button className="add-button" onClick={() => onAdd(product)} aria-label={`Add ${product.name} to cart`}>+</button></div>
      </div>
    </article>
  );
}

function PageTitle({ eyebrow, title, onBack }) {
  return <div className="page-title"><button className="back-link" onClick={onBack}>← Back</button><span className="eyebrow">{eyebrow}</span><h1>{title}</h1></div>;
}

function EmptyState({ icon, title, text, button, onClick }) {
  return <div className="empty-state"><span className="empty-icon">{icon}</span><h2>{title}</h2><p>{text}</p><button className="primary-button" onClick={onClick}>{button} <span>↗</span></button></div>;
}

function CartPage({ cart, onChange, onCheckout, onShop }) {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  return (
    <div className="cart-layout">
      <div className="cart-items">{cart.map((item) => <article className="cart-item" key={item.id}>
        <img src={item.image || item.fallbackImage} alt={item.name} onError={(event) => handleProductImageError(event, item)} />
        <div className="cart-item-copy"><span className="product-category">{item.category}</span><h3>{item.name}</h3><small>Usually ships in 1–2 days</small><div className="quantity-control"><button onClick={() => onChange(item.id, -1)} aria-label="Decrease quantity">−</button><span>{item.quantity}</span><button onClick={() => onChange(item.id, 1)} aria-label="Increase quantity">+</button></div></div>
        <strong className="cart-line-price">{money(item.price * item.quantity)}</strong>
      </article>)}<button className="text-link continue-link" onClick={onShop}>← Keep finding happy things</button></div>
      <OrderSummary cart={cart} onAction={onCheckout} action="Continue to checkout" />
    </div>
  );
}

function OrderSummary({ cart, onAction, action }) {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const delivery = subtotal >= 1499 || subtotal === 0 ? 0 : 79;
  return <aside className="order-summary"><h2>Your little total</h2><div><span>Subtotal</span><strong>{money(subtotal)}</strong></div><div><span>Delivery</span><strong>{delivery === 0 ? "On us!" : money(delivery)}</strong></div><div className="summary-total"><span>Total</span><strong>{money(subtotal + delivery)}</strong></div><p>✿ A little thank you: free delivery over ₹1,499</p>{action && <button className="primary-button" onClick={onAction}>{action} <span>→</span></button>}<small>♡ Safe, secure, and happy shopping.</small></aside>;
}

function CheckoutPage({ cart, user, onPlace }) {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const delivery = subtotal >= 1499 ? 0 : 79;
  return <div className="checkout-layout"><form className="checkout-form" onSubmit={(event) => { event.preventDefault(); onPlace(); }}><div className="form-section"><span className="checkout-step">01</span><div><h2>Where should we send your happy?</h2><div className="form-grid"><label>Full name<input defaultValue={user?.name || ""} required placeholder="Your name" /></label><label>Phone number<input type="tel" required pattern="[0-9]{10}" placeholder="10-digit mobile number" /></label><label className="field-wide">Email address<input type="email" defaultValue={user?.email || ""} required placeholder="you@example.com" /></label><label className="field-wide">Address<input required placeholder="House number, street, area" /></label><label>City<input required placeholder="City" /></label><label>PIN code<input required pattern="[0-9]{6}" placeholder="6-digit PIN" /></label></div></div></div><div className="form-section"><span className="checkout-step">02</span><div><h2>How would you like to pay?</h2><label className="payment-option"><input type="radio" name="payment" defaultChecked /><span><strong>Cash on delivery</strong><small>Pay when your happy finds arrive</small></span><span>♡</span></label><label className="payment-option"><input type="radio" name="payment" /><span><strong>UPI / online payment</strong><small>A secure payment step will follow</small></span><span>↗</span></label></div></div><button className="primary-button place-order-button" type="submit">Place my order <span>♡</span></button></form><OrderSummary cart={cart} action={null} /></div>;
}

function OrderCard({ order }) {
  const date = new Date(order.placedAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  return <article className="order-card"><div className="order-card-top"><div><span className="eyebrow">ORDER #{order.id}</span><h3>Placed {date}</h3></div><span className="order-status"><i /> On its way</span></div><div className="order-products">{order.items.map((item) => <div key={item.id}><img src={item.image || item.fallbackImage} alt="" onError={(event) => handleProductImageError(event, item)} /><span>{item.name} <small>Qty: {item.quantity}</small></span><strong>{money(item.price * item.quantity)}</strong></div>)}</div><div className="order-card-total"><span>Order total</span><strong>{money(order.total)}</strong></div></article>;
}

function AuthPage({ page, onSubmit, onNavigate }) {
  const config = {
    login: { eyebrow: "YOUR HAPPY PLACE MISSED YOU", title: "Welcome back.", text: "Sign in to pick up where your happy left off.", action: "Sign in", mode: "login" },
    signup: { eyebrow: "COME ON IN", title: "Let's make it official.", text: "Create an account for a little more everyday happy.", action: "Create my account", mode: "signup" },
    forgot: { eyebrow: "IT HAPPENS TO THE BEST OF US", title: "Forgot your password?", text: "Pop in your email and we'll help you find your way back.", action: "Send me a reset link", mode: "forgot" },
    reset: { eyebrow: "A FRESH LITTLE START", title: "Choose a new password.", text: "Make it a good one. Your next happy find is waiting.", action: "Save new password", mode: "reset" },
  }[page];
  return (
    <section className="auth-page">
      <div className="auth-art">
        <span className="auth-art-spark">✳</span>
        <div className="auth-art-photo">
          <img
            src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1000&q=85"
            alt="A thoughtful everyday accessory"
          />
        </div>
        <div className="auth-art-note">A little joy,<br /><em>just for you.</em> ♡</div>
        <span className="auth-art-caption">GOOD THINGS LIVE HERE</span>
      </div>
      <form className="auth-form" onSubmit={(event) => onSubmit(event, config.mode)}>
        <span className="eyebrow">{config.eyebrow}</span>
        <h1>{config.title}</h1>
        <p>{config.text}</p>
        {page === "signup" && (
          <label>
            Your name
            <input name="name" autoComplete="name" required placeholder="What should we call you?" />
          </label>
        )}
        {page !== "reset" && (
          <label>
            Email address
            <input name="email" type="email" autoComplete="email" required placeholder="you@example.com" />
          </label>
        )}
        {["login", "signup"].includes(page) && (
          <label>
            Password
            <input
              name="password"
              type="password"
              autoComplete={page === "login" ? "current-password" : "new-password"}
              minLength="8"
              maxLength="128"
              required
              placeholder="At least 8 characters"
            />
          </label>
        )}
        {page === "reset" && (
          <>
            <label>
              Email address
              <input name="email" type="email" autoComplete="email" required placeholder="you@example.com" />
            </label>
            <label>
              Six-digit reset code
              <input name="otp" inputMode="numeric" pattern="[0-9]{6}" maxLength="6" required placeholder="123456" />
            </label>
            <label>
              New password
              <input
                name="password"
                type="password"
                minLength="8"
                maxLength="128"
                autoComplete="new-password"
                required
                placeholder="At least 8 characters"
              />
            </label>
          </>
        )}
        <button className="primary-button auth-submit" type="submit">{config.action} <span>→</span></button>
        {page === "login" && (
          <button type="button" className="forgot-link" onClick={() => onNavigate("forgot")}>Forgot password?</button>
        )}
        {page === "login" && (
          <div className="auth-switch">New around here? <button type="button" onClick={() => onNavigate("signup")}>Create an account</button></div>
        )}
        {page === "signup" && (
          <div className="auth-switch">Already one of us? <button type="button" onClick={() => onNavigate("login")}>Sign in</button></div>
        )}
        {["forgot", "reset"].includes(page) && (
          <div className="auth-switch"><button type="button" onClick={() => onNavigate("login")}>← Back to sign in</button></div>
        )}
        <div className="auth-safe">♡ &nbsp; Your details stay yours. Always.</div>
      </form>
    </section>
  );
}

export default App;
